#include <gtk/gtk.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

GtkWidget *window[1];
GtkWidget *notebook[1];
int parent=1;

void notebook_init(void);
void ssh_widget_init(void);
void ssh_widget_pack(void);
void ssh_window_show(void);
void notebook_show(void);

char command_line[200]={"xterm -e"};

int main(int argc, char *argv[])
{
	gtk_init(&argc, &argv);
	notebook_init();
	ssh_widget_init();
	ssh_widget_pack();
	ssh_window_show();
	notebook_show();
	gtk_main();
	
	if(!parent) system(command_line);
	
	return(0);
}
