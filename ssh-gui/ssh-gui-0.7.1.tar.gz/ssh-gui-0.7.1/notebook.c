#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>

extern GtkWidget *notebook[1];
extern GtkWidget *window[1];

gint destroy(	GtkWidget *widget,
		GdkEvent  *event,
		gpointer   data )
{	
	exit(2);

	return(FALSE);
}

void notebook_init(void)
{
	window[0] = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(window[0]), "SSH GUI");
	gtk_signal_connect(GTK_OBJECT(window[0]), "delete_event",
					GTK_SIGNAL_FUNC(destroy), NULL);
					
	notebook[0] = gtk_notebook_new();
	
	gtk_container_add(GTK_CONTAINER(window[0]), notebook[0]);
}

void notebook_pack(void)
{

}

void notebook_show(void)
{
	gtk_widget_show(notebook[0]);
	gtk_widget_show(window[0]);
}