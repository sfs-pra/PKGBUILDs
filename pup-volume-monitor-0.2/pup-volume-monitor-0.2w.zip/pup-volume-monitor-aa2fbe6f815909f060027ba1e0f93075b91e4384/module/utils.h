//utils.c or utils.h
//Utilities

GIcon *pup_icon_string_to_icon(const gchar *str);
