/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef LABWC_FD_UTIL_H
#define LABWC_FD_UTIL_H

void increase_nofile_limit(void);
void restore_nofile_limit(void);

#endif /* LABWC_FD_UTIL_H */
