/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef LABWC_BORDER_H
#define LABWC_BORDER_H

struct border {
	int top;
	int right;
	int bottom;
	int left;
};

#endif /* LABWC_BORDER_H */
